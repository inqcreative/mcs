---
name: Questions and help
about: If you think you need help with something
title: ''
labels: 'Question'
assignees: ''

---

This issue tracker is intended to collect bug reports and feature requests.

For help with integrating FilePond, information on how features work, or questions about specific features of FilePond, please use [Stack Overflow](https://stackoverflow.com/questions/tagged/filepond). Any issues open for help requests will be closed to keep from clogging up the issue tracker.